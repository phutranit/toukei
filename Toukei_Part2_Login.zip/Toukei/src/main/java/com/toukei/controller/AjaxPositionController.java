package com.toukei.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.toukei.model.bean.Position;

/**
 * Handles requests for the application branch.
 */
@Controller
public class AjaxPositionController {
	
	/**
	 * Simply selects the branch view tiles to render by returning its name.
	 */
	@SuppressWarnings({ "unchecked" })
	@RequestMapping(value = "/ajaxDelPosition", method = RequestMethod.POST)
	@ResponseBody
	public void delBranch(Model model, @RequestParam("aiPosition") int iPosition,HttpSession session) {
		if(session.getAttribute("listPosition") != null) {
			List<Position> listPosition = (List<Position>)session.getAttribute("listPosition");
			try {
				listPosition.get(iPosition).setFlg(1);
			}catch(Exception e) {
				
			}
		}
	}
}

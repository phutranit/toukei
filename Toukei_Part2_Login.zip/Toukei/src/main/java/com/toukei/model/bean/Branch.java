package com.toukei.model.bean;

import java.io.Serializable;

public class Branch implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int id;
	private int no;
	private String name;
	private int clinicID;
	private int flg;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getClinicID() {
		return clinicID;
	}

	public void setClinicID(int clinicID) {
		this.clinicID = clinicID;
	}

	public int getFlg() {
		return flg;
	}

	public void setFlg(int flg) {
		this.flg = flg;
	}
	
	
	public Branch(int id, int no, String name, int clinicID, int flg) {
		super();
		this.id = id;
		this.no = no;
		this.name = name;
		this.clinicID = clinicID;
		this.flg = flg;
	}
	
	public Branch() {
		super();
	}

	@Override
	public String toString() {
		return "Branch [id=" + id + ", no=" + no + ", name=" + name + ", clinicID=" + clinicID + ", flg=" + flg + "]";
	}

	public Branch(int no, String name) {
		super();
		this.no = no;
		this.name = name;
	}
	
	
	
}

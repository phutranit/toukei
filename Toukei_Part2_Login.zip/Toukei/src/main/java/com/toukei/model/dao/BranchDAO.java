package com.toukei.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.toukei.model.bean.Branch;

@Repository
public class BranchDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Branch> getItems() {
		String sql 	=	"SELECT ID, NO , NAME, CLINICID, FLG "+
						"FROM CLI_BRANCH "+
						"WHERE FLG = 0 "+
						"ORDER BY NO ASC ";
		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<Branch>(Branch.class));
	}
	
	public Branch checkNo(int no) {
		String sql =	"SELECT ID, NO , NAME, CLINICID, FLG "+
						"FROM CLI_BRANCH "+
						"WHERE FLG = 0 AND NO = ? ";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] {no},new BeanPropertyRowMapper<Branch>(Branch.class));
		}catch(Exception e) {
			return null;
		}
	}
	
	public Branch checkNoByFlg(int no) {
		String sql =	"SELECT ID, NO , NAME, CLINICID, FLG "+
						"FROM CLI_BRANCH "+
						"WHERE FLG = 1 AND NO = ? ";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] {no},new BeanPropertyRowMapper<Branch>(Branch.class));
		}catch(Exception e) {
			return null;
		}
	}
	
	@Transactional(rollbackFor=Exception.class)
	public void update(List<Branch> listBranchUpdate,List<Branch> listBranchDelete,List<Branch> listBranchInsert) {
		String sql1 = "UPDATE CLI_BRANCH SET NAME = ? WHERE NO = ? ";
		String sql2 = "UPDATE CLI_BRANCH SET FLG = ? WHERE ID = ? ";
		String sql3 = "INSERT INTO CLI_BRANCH(NAME,NO) VALUES(?,?) ";
		// edit name
		for (Branch branch : listBranchUpdate) {
			jdbcTemplate.update(sql1,new Object[] {branch.getName(),branch.getNo()});
		}
		//edit flag
		for (Branch branch : listBranchDelete) {
			jdbcTemplate.update(sql2,new Object[] {branch.getFlg(),branch.getId()});
		}
		// insert 
		for (Branch branch : listBranchInsert) {
			jdbcTemplate.update(sql3,new Object[] {branch.getName(),branch.getNo()});
		}
	}
}

package com.toukei.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.toukei.model.dao.BranchDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "file:src/main/webapp/WEB-INF/spring/appConfig/config-jdbc.xml",
		"file:src/main/webapp/WEB-INF/spring/appConfig/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appConfig/config-security.xml" })
public class BranchDAOTest {
	@Autowired
	private BranchDAO branchDAO;

	@Test
	public void testGetItems() {
		assertTrue(branchDAO.getItems() != null);
	}
	
	@Test
	public void testCheckNo() {
		assertTrue(branchDAO.checkNo(0) == null);
	}

	@Test
	public void testCheckNoByFlg() {
		assertTrue(branchDAO.checkNoByFlg(0) == null);
	}
}

package com.toukei.util;

public class PasswordUtil {

	public static void main(String[] args) {
		System.out.println("3 password old user");
		String password = "phu123!@|cuem123!@Q12U|Demoser5!@#";
		String arPass3Old[] = password.split("\\|");
		for (String string : arPass3Old) {
			System.out.println(string);
		}
		System.out.println("-------------------------");
		String presentPassword = "supperdemo";
		String newPassword = "passwordmoiday";
		String strPass3OldNew;
		/*
		 * for (String item : arPass3Old) { if(newPassword.equals(presentPassword)) {
		 * System.out.println("Duplicate current password."); return; }else
		 * if(newPassword.equals(item)) {
		 * System.out.println("This password coincides with your old 3 passwords");
		 * return; } }
		 */

		System.out.println("==========================================");
		System.out.println("==========================================");

		if (checkPassword(password, presentPassword, newPassword)) {
			System.out.println(str3PasswordNew(password, newPassword));
		} else {
			System.out.println("password not ok!");
		}
	}

	public static boolean checkPassword(String str3PassOld, String presentPassword, String newPassword) {
		String arPass3Old[] = str3PassOld.split("\\|");
		for (String item : arPass3Old) {
			if (newPassword.equals(presentPassword) || newPassword.equals(item)) {
				return false;
			}
		}
		return true;
	}

	public static String str3PasswordNew(String str3PassOld, String newPassword) {
		String arPass3Old[] = str3PassOld.split("\\|");
		StringBuilder str = new StringBuilder();
		for (int i = 1; i <= arPass3Old.length; i++) {
			if (i > 1) {
				str.append(arPass3Old[i - 1] + "|");
			}
			if (i == arPass3Old.length) {
				str.append(newPassword);
			}
		}
		return str.toString();
	}
}

package com.toukei.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	public static int monthsSince(Date pastDate) {
	    Calendar present = Calendar.getInstance();
	    Calendar past = Calendar.getInstance();
	    past.setTime(pastDate);

	    int months = 0;

	    while (past.before(present)) {
	        past.add(Calendar.MONTH, 1);
	        if (past.before(present)) {
	        	months++;
	        }
	    } return months;
	}
}

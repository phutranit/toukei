package com.toukei.model.bean;

public class User {
	private int id;
	private String username;
	private String password;
	private String fullname;
	private int enable;
	private int role_id;
	private int accountNonlocked;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public int getEnable() {
		return enable;
	}

	public void setEnable(int enable) {
		this.enable = enable;
	}

	public int getRole_id() {
		return role_id;
	}

	public void setRole_id(int role_id) {
		this.role_id = role_id;
	}

	public int getAccountNonlocked() {
		return accountNonlocked;
	}

	public void setAccountNonlocked(int accountNonlocked) {
		this.accountNonlocked = accountNonlocked;
	}

	public User(int id, String username, String password, String fullname, int enable, int role_id,
			int accountNonlocked) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.fullname = fullname;
		this.enable = enable;
		this.role_id = role_id;
		this.accountNonlocked = accountNonlocked;
	}

	public User() {
		super();
	}

}

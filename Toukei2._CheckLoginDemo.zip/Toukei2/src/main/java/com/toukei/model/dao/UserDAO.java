package com.toukei.model.dao;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.toukei.model.bean.User;
@Repository
public class UserDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public User getItemByUser(String username) {
		String sql =	"SELECT ID, USERNAME, FULLNAME, ENABLE, ROLE_ID, ACCOUNTNONLOCKED "+
						"FROM CLI_USERS "+
						"WHERE USERNAME = ? ";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] {username},new BeanPropertyRowMapper<User>(User.class));
		}catch(Exception e) {
			return null;
		}
	}
	
	@Transactional(rollbackFor = Exception.class)
	public void editAccountNonlockedByUser(String username) {
		String sql = "UPDATE CLI_USERS SET ACCOUNTNONLOCKED = 0 ,ENABLE = 0 WHERE USERNAME = ?";
		jdbcTemplate.update(sql, new Object[] { username });
	}
	
	public Timestamp geTimestamp(String username) {
		String sql =	"SELECT TIMEREPASS "+
						"FROM CLI_USERS "+
						"WHERE USERNAME = ? ";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] {username},Timestamp.class);
		}catch(Exception e) {
			return null;
		}
	}
}

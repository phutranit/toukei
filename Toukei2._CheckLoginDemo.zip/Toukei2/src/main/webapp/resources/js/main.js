/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


	$(function () {
		var href = location.href;
		$('.nav a').each(function (e) {
			if (href.indexOf($(this).attr('href')) > 0) {
				$(this).parent().addClass('active');
			}
		});
	});

$(document).ready(function(){
	$("#add").click(function (e) {
		 //Append a new row of code to the "#items" div
		 $("#items1").append('<li><div class="left-icon"><input name="branchno" type="text" value="" /><i class="fa fa-chevron-right"></i></div><div><input name="branchname" type="text" value=""/></div><div class="delete-icon"><button class="delete"><i class="fa fa-trash-o"></i></button></div></li>');
		 });
	$("#add-2").click(function (e) {
		 //Append a new row of code to the "#items" div
		$("#items2").append('<li><div class="left-icon"><input name="positionno" type="text" value=""/><i class="fa fa-chevron-right"></i></div><div><input name="positionname" type="text" value=""/></div><div class="delete-icon"><button class="delete"><i class="fa fa-trash-o"></i></button></div></li>');
		 });
	$("body").on("click", ".delete", function (e) {
		 $(this).closest('li').remove()
	});
});

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function() {
	// ================staff add page js======================/
	$("#add_staff_button").click(function() {
		$("#dialog_add_staff").dialog("open");
	});
	$("#dialog_add_staff").dialog({
		autoOpen : false,
		position : 'center',
		title : 'ADD STAFF',
		draggable : true,
		width : 300,
		height : 400,
		resizable : true,
		modal : true,
		show : "fade",
		hide : "fade"
	});
	// ================staff edit page js======================/
	$("#edit_staff_button").click(function() {
		$("#dialog_edit_staff").dialog("open");
	});
	$("#dialog_edit_staff").dialog({
		autoOpen : false,
		position : 'center',
		title : 'EDIT STAFF',
		draggable : true,
		width : 300,
		height : 400,
		resizable : true,
		modal : true,
		show : "fade",
		hide : "fade"
	});
	// ================staff delete page js======================/
	$("#delete_staff_button").click(function() {
		$("#dialog_delete_staff").dialog("open");
	});
	$("#dialog_delete_staff").dialog({
		autoOpen : false,
		position : 'center',
		title : 'DELETE STAFF',
		draggable : true,
		width : 300,
		height : 400,
		resizable : true,
		modal : true,
		show : "fade",
		hide : "fade"
	});
	// ================name edit js======================/
	$("#name_edit_button").click(function() {
		$("#dialog_name_edit").dialog("open");
	});
	$('#dialog_name_edit').dialog({
		autoOpen : false,
		position : 'center',
		title : 'NAME EDIT',
		draggable : true,
		width : 300,
		height : 400,
		resizable : true,
		modal : true,
		show : "fade",
		hide : "fade"
	});
	// ================shift_edit page js======================/
	$("#shift_edit_button").click(function() {
		$("#dialog_shift_edit").dialog("open");
	});
	$('#dialog_shift_edit').dialog({
		autoOpen : false,
		position : 'center',
		title : 'SHIFT EDIT',
		draggable : true,
		width : 560,
		height : 500,
		resizable : true,
		modal : true,
		show : "fade",
		hide : "fade"
	});
	// ================schedule_select page js======================/
	$("#schedule_select_button").click(function() {
		$("#dialog_schedule_select").dialog("open");
	});
	$('#dialog_schedule_select').dialog({
		autoOpen : false,
		position : 'center',
		title : 'SCHEDULE SELECT',
		draggable : true,
		width : 550,
		height : 500,
		resizable : true,
		modal : true,
		show : "fade",
		hide : "fade"
	});

});

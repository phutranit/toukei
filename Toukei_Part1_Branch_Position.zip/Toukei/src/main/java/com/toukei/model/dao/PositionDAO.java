package com.toukei.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.toukei.model.bean.Position;

@Repository
public class PositionDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Position> getItems() {
		String sql = 	"SELECT ID, NO , NAME, CLINICID, FLG " + 
						"FROM CLI_POSITION " + "WHERE FLG = 0 "+
						"ORDER BY NO ASC ";
		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<Position>(Position.class));
	}

	public Position checkNo(int no) {
		String sql = 	"SELECT ID, NO , NAME, CLINICID, FLG " + 
						"FROM CLI_POSITION " + 
						"WHERE FLG = 0 AND NO = ?";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { no },
					new BeanPropertyRowMapper<Position>(Position.class));
		} catch (Exception e) {
			return null;
		}
	}

	public Position checkNoByFlg(int no) {
		String sql = 	"SELECT ID, NO , NAME, CLINICID, FLG " + 
						"FROM CLI_POSITION " + 
						"WHERE FLG = 1 AND NO = ?";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { no },
					new BeanPropertyRowMapper<Position>(Position.class));
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void update(List<Position> listPositionUpdate, List<Position> listPositionDelete,
			List<Position> listPositionInsert) {
		String sql1 = 	"UPDATE CLI_POSITION SET NAME = ? WHERE NO = ? ";
		String sql2 = 	"UPDATE CLI_POSITION SET FLG = ? WHERE ID = ? ";
		String sql3 = 	"INSERT INTO CLI_POSITION(NAME,NO) VALUES(?,?) ";
		// edit name
		for (Position po : listPositionUpdate) {
			jdbcTemplate.update(sql1, new Object[] { po.getName(), po.getNo() });
		}
		// edit flag
		for (Position po : listPositionDelete) {
			jdbcTemplate.update(sql2, new Object[] { po.getFlg(), po.getId() });
		}
		// insert
		for (Position po : listPositionInsert) {
			jdbcTemplate.update(sql3, new Object[] { po.getName(), po.getNo() });
		}
	}
}

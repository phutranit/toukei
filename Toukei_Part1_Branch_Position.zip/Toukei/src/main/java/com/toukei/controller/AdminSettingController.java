package com.toukei.controller;

import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application setting.
 */
@Controller
public class AdminSettingController {
	/**
	 * Simply selects the setting view tiles to render by returning its name.
	 */
	@RequestMapping(value = "/setting", method = RequestMethod.GET)
	public String index(Locale locale, Model model) {
		return "admin.setting.index";
	}
	
}

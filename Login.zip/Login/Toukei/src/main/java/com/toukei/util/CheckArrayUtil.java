package com.toukei.util;

import java.util.Arrays;

public class CheckArrayUtil {

	public static int findPopular(int[] a) {

		if (a == null || a.length == 0)
			return 0;

		Arrays.sort(a);

		int previous = a[0];
		int popular = a[0];
		int count = 1;
		int maxCount = 1;

		for (int i = 1; i < a.length; i++) {
			if (a[i] == previous)
				count++;
			else {
				if (count > maxCount) {
					popular = a[i - 1];
					maxCount = count;
				}
				previous = a[i];
				count = 1;
			}
		}

		return count > maxCount ? a[a.length - 1] : popular;
	}

	public static String findPopular(String[] a) {

		if (a == null || a.length == 0)
			return "";

		Arrays.sort(a);

		String previous = a[0];
		String popular = a[0];
		int count = 1;
		int maxCount = 1;

		for (int i = 1; i < a.length; i++) {
			if (a[i].equals(previous))
				count++;
			else {
				if (count > maxCount) {
					popular = a[i - 1];
					maxCount = count;
				}
				previous = a[i];
				count = 1;
			}
		}

		return count > maxCount ? a[a.length - 1] : popular;

	}
}

package com.toukei.model.bean;

import java.sql.Timestamp;

public class UserAttempts {
	private int id;
	private String username;
	private int attempts;
	private Timestamp lastModified;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getAttempts() {
		return attempts;
	}

	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

	public Timestamp getLastModified() {
		return lastModified;
	}

	public void setLastModified(Timestamp lastModified) {
		this.lastModified = lastModified;
	}

	public UserAttempts() {
		super();
	}

	public UserAttempts(int id, String username, int attempts, Timestamp lastModified) {
		super();
		this.id = id;
		this.username = username;
		this.attempts = attempts;
		this.lastModified = lastModified;
	}

	@Override
	public String toString() {
		return "UserAttempts [id=" + id + ", username=" + username + ", attempts=" + attempts + ", lastModified="
				+ lastModified + "]";
	}
	
}

package com.toukei.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application schedule.
 */
@Controller
public class AdminScheduleController {
	/**
	 * Simply selects the schedule view tiles to render by returning its name.
	 */
	@RequestMapping(value = { "/schedule" }, method = RequestMethod.GET)
	public String index(ModelMap model) {
		return "admin.schedule.index";
	}
}

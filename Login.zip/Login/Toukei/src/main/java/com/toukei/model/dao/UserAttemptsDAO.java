package com.toukei.model.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.toukei.model.bean.UserAttempts;
@Repository
public class UserAttemptsDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Transactional(rollbackFor = Exception.class)
	public void addAttemptsByUser(UserAttempts userAttempts) {
		String sql = "INSERT INTO CLI_USERATTEMPTS (USERNAME, ATTEMPTS, LASTMODIFIED) VALUES(?,?,?)";
		jdbcTemplate.update(sql, new Object[] { userAttempts.getUsername(), userAttempts.getAttempts(),userAttempts.getLastModified() });
	}
	public UserAttempts getItemByUser(String username) {
		String sql =	"SELECT USERNAME, ATTEMPTS, LASTMODIFIED "+
						"FROM CLI_USERATTEMPTS "+
						"WHERE USERNAME = ? ";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] {username},new BeanPropertyRowMapper<UserAttempts>(UserAttempts.class));
		}catch(Exception e) {
			return null;
		}
	}
	
	
	@Transactional(rollbackFor = Exception.class)
	public void editAttemptsByUser(UserAttempts userAttempts) {
		String sql = "UPDATE CLI_USERATTEMPTS SET ATTEMPTS = ?, LASTMODIFIED = ?  WHERE USERNAME = ?";
		jdbcTemplate.update(sql, new Object[] {  userAttempts.getAttempts(),userAttempts.getLastModified() ,userAttempts.getUsername()});
	}
	
	@Transactional(rollbackFor = Exception.class)
	public void editAttemptsLoginSuccessByUser(String username) {
		String sql = "UPDATE CLI_USERATTEMPTS SET ATTEMPTS = 0  WHERE USERNAME = ?";
		jdbcTemplate.update(sql, new Object[] { username});
	}
	
	/*@Transactional(rollbackFor = Exception.class)
	public void resetAttemptsLoginByUser(UserAttempts usAttempts) {
		String sql = "UPDATE CLI_USERATTEMPTS SET ATTEMPTS = ?, LASTMODIFIED = ?  WHERE USERNAME = ?";
		jdbcTemplate.update(sql, new Object[] { usAttempts.getAttempts(), usAttempts.getLastModified(), usAttempts.getUsername()});
	}*/
	

}

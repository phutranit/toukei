package com.toukei.util;

public class PasswordUtil {
	public static boolean checkPassword(String str3PassOld, String presentPassword, String newPassword) {
		String arPass3Old[] = str3PassOld.split("\\|");
		for (String item : arPass3Old) {
			if (newPassword.equals(presentPassword) || newPassword.equals(item)) {
				return false;
			}
		}
		return true;
	}

	public static String str3PasswordNew(String str3PassOld, String newPassword) {
		String arPass3Old[] = str3PassOld.split("\\|");
		StringBuilder str = new StringBuilder();
		for (int i = 1; i <= arPass3Old.length; i++) {
			if (i > 1) {
				str.append(arPass3Old[i - 1] + "|");
			}
			if (i == arPass3Old.length) {
				str.append(newPassword);
			}
		}
		return str.toString();
	}
}

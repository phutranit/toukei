package com.toukei.controller;

import java.security.Principal;
import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.toukei.model.bean.UserAttempts;
import com.toukei.model.dao.UserAttemptsDAO;
import com.toukei.model.dao.UserDAO;
import com.toukei.util.DateUtil;

/**
 * Handles requests for the application branch.
 */
@Controller
public class AuthController {
	@Autowired
	private UserAttemptsDAO userAttemptsDAO;
	@Autowired
	private UserDAO userDAO;

	public static final String LAST_USERNAME_KEY = "LAST_USERNAME";

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String home(Model model, Principal principal, HttpSession session,
			@RequestParam(value = "error", required = false) String error, HttpServletRequest request,RedirectAttributes ra) {
		int checkNumLogin = 1;
		String username = "";
		int checkAttempts = 0;
		if ("loginErr".equals(error)) {

			if (session.getAttribute(LAST_USERNAME_KEY) != null) {
				username = (String) session.getAttribute(LAST_USERNAME_KEY);
			}

			UserAttempts userAttempts = new UserAttempts(0, username, checkNumLogin,
					new Timestamp(new Date().getTime()));
			
			if (userDAO.getItemByUser(username) != null) {
				UserAttempts usAttempts = userAttemptsDAO.getItemByUser(username);
				if (usAttempts != null) {
					checkAttempts = usAttempts.getAttempts();
					if (((checkAttempts + 1) == 5 && DateUtil.minSince(usAttempts.getLastModified()) <= 10 ) ||  userDAO.getItemByUser(username).getAccountNonlocked() == 0) {
						checkNumLogin = 5;
						userAttempts.setAttempts(checkNumLogin);
						userAttemptsDAO.editAttemptsByUser(userAttempts);
						try {
							userDAO.editAccountNonlockedByUser(username);
						} catch (Exception e) {
							return "redirect:/login?error=loginErr";
						}
						return "redirect:/login?error=enable";
					} else {
						if(checkAttempts < 5 && DateUtil.minSince(usAttempts.getLastModified()) > 10) {
							checkNumLogin = 1;
						}else if(checkAttempts < 5 && DateUtil.minSince(usAttempts.getLastModified()) < 10){
							checkNumLogin = usAttempts.getAttempts() + 1;
							if(checkNumLogin == 3 || checkNumLogin == 4) {
								model.addAttribute("msg",
								"This is the "+checkNumLogin+"st time you login if you enter more than " + (5 - checkNumLogin)+ " wrong then your account will be disabled.<br /> "
								+ "If you do not want your account disabled, please wait for 10 minutes, your account returns to its original state.");
							}
						}
					}
					userAttempts.setAttempts(checkNumLogin);
					userAttemptsDAO.editAttemptsByUser(userAttempts);
				} else {
					userAttemptsDAO.addAttemptsByUser(userAttempts);
				}
			}
		}
		return "/auth/login";
	}
}
